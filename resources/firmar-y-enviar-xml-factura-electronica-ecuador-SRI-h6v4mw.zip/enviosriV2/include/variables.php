<?php

// variables

/// Variables
 $rucem = '13165469126';