# factura-ec
Libreria para envio a SRI
firmar y enviar al SRI
Funciona con certificado del banco nacional de Ecuador
Necesita asesoría 5116419141