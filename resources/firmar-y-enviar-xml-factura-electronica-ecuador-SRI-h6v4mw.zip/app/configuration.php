<?php

 // Configura path host
    define('HOST', 'http://localhost/factura-ec');
       


