<?php 
include ('configuration.php');  ?>

<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>
    <div id="response">

    </div>

</body>

<script src="<?php echo HOST; ?>/js/fiddle.js"></script>
<script src="<?php echo HOST; ?>/js/forge.min.js"></script>
<script src="<?php echo HOST; ?>/js/moment.min.js"></script>
<script src="<?php echo HOST; ?>/js/buffer.js"></script>



